////*******************************************************************************************
//// *                         TP1: Détection de la peau	                             *
////  *                        Matière: VISION PAR ORDINATEUR                               *
////   *                                                                                   *              
////    *                      Etudiant: MEDOU Daniel Magloire, Promo21                   *             
////     *                     Niveau: Master 2, option SIM                              *             
////      *******************************************************************************

#include <stdio.h>
#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <string>

#define NB_IMAGE 25
#define PATH_TO_PEAU_IMAGES "base/peau/"
#define PATH_TO_NON_PEAU_IMAGES "base/non-peau/"

using namespace std;
using namespace cv;

float** histo(string type, int echelle, float &nb_pixels) {

	float facteur_de_reduction = (float) echelle / 256;

	//Choix du répertoire d'images
	char* PATH;

	if (type.compare("peau") == 0) {
		PATH = PATH_TO_PEAU_IMAGES;
	} else if (type.compare("non_peau") == 0) {
		PATH = PATH_TO_NON_PEAU_IMAGES;
	} else {
		cout << "Attention mauvais répertoire!";
		cout << "Entrer le bon type de peau";
	}

	//Matrice devant contenir l'histogramme: Construction
	float ** histo; //histogramme
	histo = new float*[echelle];
	for (int i = 0; i < echelle; i++) {
		histo[i] = new float[echelle];
		for (int j = 0; j < echelle; j++) {
			histo[i][j] = 0;
		}
	}

	//Construction de l'histogramme
	for (int i = 1; i <= NB_IMAGE; i++) {

		//définir le nom de l'image
		char nom_img[50] = "";
		strcat(nom_img, PATH); //la fonction strcat en C ajoute la chaine indiquée par "src" à la fin de la chaine pointée pas "dest"
		char num[2] = "";
		sprintf(num, "%d", i);
		strcat(nom_img, num);
		strcat(nom_img, ".jpg");

		//chargement de l'image
		Mat img;
		img = imread(nom_img, 1);

		if (!img.data) {
			cout << "Mauvaise image, veuillez entrer une image valide " << endl;
			exit(0);
		} else {

			// Espace lab: Convertir dans cet espace
			Mat rendu;
			cvtColor(img, rendu, CV_BGR2Lab);

			// Parcours de l'image pour remplissage de l'histogramme
			for (int k = 0; k < rendu.rows; k++) {
				for (int l = 0; l < rendu.cols; l++) {

					// choix des valeurs a et b
					int a = rendu.at<Vec3b>(k, l).val[1]
							* facteur_de_reduction;
					int b = rendu.at<Vec3b>(k, l).val[2]
							* facteur_de_reduction;

					//Histogramme:  Mise à jour de ces valeurs
					if (img.at<Vec3b>(k, l) != Vec3b(0, 0, 0)) {

						histo[a][b] = histo[a][b] + 1;
					}
				}
			}
		}
	}

	// Lissage de l'histogramme afin d'améliorer la detection:
			//moyenne de la valeur des 8 pixels voisin et la valeur du pixel

			for (int i = 1; i < (echelle - 1); i++) {
				for (int j = 1; j < (echelle - 1); j++) {
					histo[i][j] = histo[i][j]
							+ (histo[i - 1][j - 1] + histo[i - 1][j]
									+ histo[i - 1][j + 1] + histo[i][j - 1]
									+ histo[i][j + 1] + histo[i + 1][j - 1]
									+ histo[i + 1][j] + histo[i + 1][j + 1])
									/ 8;
				}
			}

	//Normaisation de l'histogramme
	for (int m = 0; m < echelle; m++) {
		for (int n = 0; n < echelle; n++) {
			if(histo[m][n] !=0)
				nb_pixels += histo[m][n];

		}
	}

	for (int m = 0; m < echelle; m++) {
			for (int n = 0; n < echelle; n++) {
				if(histo[m][n] !=0)
								histo[m][n] /= nb_pixels;

			}
		}



	return histo;//histogramme
}

//Evaluation de perforances du programme

void evaluation(Mat img_reference, Mat img_detecte) {

	int nb_pixels_peau_vrai = 0;
	int nb_pixels_peau_faux_pos = 0;
	int nb_pixels_peau_img_reference = 0;
	int nb_pixels_peau_faux_neg = 0;
	float performance;

	for (int i = 0; i < img_detecte.rows; i++) {
		for (int j = 0; j < img_detecte.cols; j++) {

			Vec3b rendu = img_detecte.at<Vec3b>(i, j);
			Vec3b original = img_reference.at<Vec3b>(i, j);
			// Nombre de pixel peau détecté dans le rendu
			// le pixel de l'image de rendu et de l'image de référence sont tous différent de noir
			if (rendu != Vec3b(0, 0, 0) && original != Vec3b(0, 0, 0)) {

				nb_pixels_peau_vrai++;
			}
			// pixel peau mal détecté
			if (rendu != Vec3b(0, 0, 0) && original == Vec3b(0, 0, 0)) {
				nb_pixels_peau_faux_pos++;
			}
			// pixel peau dans l'image de référence
			if (original != Vec3b(0, 0, 0)) {
				nb_pixels_peau_img_reference++;
			}
		}
	}

	nb_pixels_peau_faux_neg = nb_pixels_peau_img_reference -nb_pixels_peau_vrai;
	if(nb_pixels_peau_faux_neg < 0.0)
		nb_pixels_peau_faux_neg=0.0;

//Calcul de la performance du programme
	performance = (float)nb_pixels_peau_vrai/(nb_pixels_peau_vrai
					+nb_pixels_peau_faux_pos + nb_pixels_peau_faux_neg);
	cout << "reference :"<<nb_pixels_peau_img_reference<< endl;
	cout << "correct :"<<nb_pixels_peau_vrai<< endl;
	cout << "faux_positif :"<<nb_pixels_peau_faux_pos<< endl;
	cout << "faux_negatif :"<<nb_pixels_peau_faux_neg<< endl;

	cout << "Perfomance du programme = " << performance * 100 << " %" << endl;

}

// méthode simple pour détecter la peau
Mat detection_peau_simple(float** histo_peau, float** histo_non_peau,
		Mat img_test, int echelle) {

	float facteur_de_reduction = (float) echelle / 256;
	//conversion de l'image test dans l'espace lab
	Mat rendu;
	cvtColor(img_test, rendu, CV_BGR2Lab);

	Mat masque(img_test.rows, img_test.cols, CV_8UC1);
	masque = Scalar(0);
	Mat sortie;
	img_test.copyTo(sortie);
	for (int k = 0; k < rendu.rows; k++) {
		for (int l = 0; l < rendu.cols; l++) {

			// choix des valeurs a et b
			int a = rendu.at<Vec3b>(k, l).val[1] * facteur_de_reduction;
			int b = rendu.at<Vec3b>(k, l).val[2] * facteur_de_reduction;

			//if(a!=0 || b!=0)
			//cout<< "a :"<< a << " b :"<< b << endl;
			// mise à jour des valeurs de l'histogramme
			if (histo_peau[a][b] < histo_non_peau[a][b]) {

				sortie.at<Vec3b>(k, l) = Vec3b(0, 0, 0);

			} else {
				masque.at<uchar>(k, l) = 255;
			}
		}
	}

	imshow("image entree", img_test);

	imshow("masque", masque);
	imshow("sortie", sortie);

	return sortie;
}

// Détection de peau par calcul de probabilité
Mat detection_peau_bayes(float** histo_peau, float** histo_non_peau,
		Mat img_test, int echelle, float seuil, float nb_pixels_peau,
		float nb_pixels_non_peau) {

	float facteur_de_reduction = (float) echelle / 256;
	float proba_peau = 0.0;
	float proba_non_peau = 0.0;

	//calcul des probabilités peau et non peau

	proba_peau = nb_pixels_peau / (nb_pixels_peau + nb_pixels_non_peau);
	proba_non_peau = nb_pixels_non_peau / (nb_pixels_peau + nb_pixels_non_peau);


	//conversion de l'image test dans l'espace lab
	Mat rendu;
	cvtColor(img_test, rendu, CV_BGR2Lab);

	// création du masque
	Mat masque(img_test.rows, img_test.cols, CV_8UC1);
	masque = Scalar(0);

	//création de l'image résultat
	Mat sortie;
	img_test.copyTo(sortie);

	for (int k = 0; k < rendu.rows; k++) {
		for (int l = 0; l < rendu.cols; l++) {

			// choix des valeurs a et b
			int a =0, b=0;
			 a = rendu.at<Vec3b>(k, l).val[1] * facteur_de_reduction;
			 b = rendu.at<Vec3b>(k, l).val[2] * facteur_de_reduction;
			 //calcul de la probabilité de décision
			 float proba_decision = 0.0;
			 proba_decision = (histo_peau[a][b] * proba_peau)
					/ (histo_peau[a][b] * proba_peau
							+ histo_non_peau[a][b] * proba_non_peau);

			// mise à jour des valeurs de l'histogramme
			if (proba_decision > seuil) {
				masque.at<uchar>(k, l) = 255;

			} else {
				sortie.at<Vec3b>(k, l) = Vec3b(0, 0, 0);
			}
		}

	}

	//Post traitement
	int erosion_size = 1;
	int dilatation_size = 3;

	Mat dilate_element = getStructuringElement(MORPH_CROSS,
			Size(2 * dilatation_size + 1, 2 * dilatation_size + 1),
			Point(dilatation_size, dilatation_size));

	Mat erode_element = getStructuringElement(MORPH_CROSS,
			Size(2 * erosion_size + 1, 2 * erosion_size + 1),
			Point(erosion_size, erosion_size));
	dilate(sortie, sortie, dilate_element);

	erode(sortie, sortie, erode_element);

	imshow("image entree", img_test);

	imshow("masque", masque);
	imshow("sortie", sortie);


	return sortie;

}

// Affichage de l'histogramme
void histogramme_print(float ** histo, int echelle, string type) {

	Mat big_histo(256, 256, CV_8UC1);
	float valeur_maximale = 0.0;

	//Détermination de la valeur maximale de l'histogramme

	for (int i = 0; i < echelle; i++) {
		for (int j = 0; j < echelle; j++) {
			if (histo[i][j] > valeur_maximale)
				valeur_maximale = histo[i][j];
		}
	}

	//Agrandissement, normalisation de la matrice de l'histogramme et transformation en image

	for (int i = 0; i < echelle; i++) {
		for (int j = 0; j < echelle; j++) {
			for (int k = 0; k < 256/echelle; k++) {
				for (int l = 0; l < 256/echelle; l++)
					big_histo.at<uchar>(i * 256/echelle + k, j * 256/echelle + l) =
							saturate_cast<uchar>(
									((histo[i][j]) / valeur_maximale)
											* 255);
						}
		}
	}

	// Enregistrement de l'histogramme
	char nom_histo[50] = "";
	strcat(nom_histo, "histogramme/histogramme_");
	if (type.compare("peau") == 0) {
		strcat(nom_histo, "peau");
	} else {
		strcat(nom_histo, "non-peau");
	}
	strcat(nom_histo, ".jpg");
	if (!imwrite(nom_histo, big_histo))
		cout << "Erreur lors de l'enregistrement" << endl;

	// Affichage de l'histogramme
	imshow(nom_histo, big_histo);
}

// Fonction principale
int main(int argc, char** argv) {

	int echelle = 0;
	float seuil = 0.0;
	echelle = atoi(argv[1]);
	seuil = atof(argv[2]);
	float ** histo_peau = NULL;
	float ** histo_non_peau = NULL;
	float nb_pixels_peau = 0;
	float nb_pixels_non_peau = 0;
	char* arg_nom = argv[3];
	char nom_img_test[50]= "";
	strcat(nom_img_test,"base/test/");
	strcat(nom_img_test,arg_nom);

	// Lecture de l'image entrée
	Mat img_entre;
	img_entre = imread(nom_img_test, 1);

	char nom_img_reference[50] = PATH_TO_PEAU_IMAGES;
	strcat(nom_img_reference,arg_nom);

	// Lecture de l'image de référence
	Mat img_reference;
	img_reference = imread(nom_img_reference, 1);
	imshow("image reference", img_reference);


	Mat img_detecte;

	// calcul des histogrammes
	histo_peau = histo("peau", echelle, nb_pixels_peau);

	histo_non_peau = histo("non_peau", echelle, nb_pixels_non_peau);

	//	image_detectee = detection_peau_simple(histo_peau, histo_non_peau, img_entre, echelle);

	img_detecte = detection_peau_bayes(histo_peau, histo_non_peau,
			img_entre, echelle, seuil, nb_pixels_peau, nb_pixels_non_peau);

	char nom_img_rendu[50] ="";
		strcat(nom_img_rendu,"rendu/");
		strcat(nom_img_rendu,"rendu_image_");
		strcat(nom_img_rendu,arg_nom);
		if (!imwrite(nom_img_rendu, img_detecte))
				cout << "Erreur lors de l'enregistrement" << endl;

	evaluation(img_reference, img_detecte);
	histogramme_print(histo_peau,echelle,"peau");
	histogramme_print(histo_non_peau,echelle,"non_peau");
	waitKey(0);
	return 0;
}
