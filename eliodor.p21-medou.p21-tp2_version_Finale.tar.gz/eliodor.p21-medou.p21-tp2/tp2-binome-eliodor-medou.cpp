////****************************************************************************************************////
////                          DETECTION ET RECONNAISSANCE DE VISAGE     							    ////
////                                                                                                    ////
////																									////
////             Binome :   ELIODOR Ednalson Guy Mirlin (P20)                                           ////
////                        DANIEL Medou Magloire (P20)                                    				////
////                                                                                       				////
////																									////
////             Compilation: 1- make      												 				////
////						  2- ./reconnaissance_visage_simple xxx.txt  xxxx.txt	    			    ////
////																									////
////		     Notre programme permet de détecter comme demande les visages dans les images     	    ////
////                                   																	////
////****************************************************************************************************////

#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include "opencv2/core/core.hpp"
#include "opencv2/contrib/contrib.hpp"

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <vector>

using namespace std;
using namespace cv;

void detectAndDisplaysimple(Mat frame);
void detectAndDisplaydiscrimination(Mat frame);

//Variables globales
String face_cascade_name = "/usr/share/opencv/haarcascades/haarcascade_frontalface_alt.xml";
String eyes_cascade_name = "/usr/share/opencv/haarcascades/haarcascade_eye_tree_eyeglasses.xml";
String mouth_cascade_name = "/usr/share/opencv/haarcascades/haarcascade_mcs_mouth.xml";
String nose_cascade_name = "/usr/share/opencv/haarcascades/haarcascade_mcs_nose.xml";
CascadeClassifier face_cascade;
CascadeClassifier eyes_cascade;
CascadeClassifier nose_cascade;

String window_name = "Capture - Face detection";
int nb_classes = 0;

//Distance euclidienne d'un vecteur vers un ensemble de vecteurs

vector<double> dist_vec_to_set(vector<Mat> projected_training_images,
		Mat projected_test_image) {

	vector<double> distances;

	for (size_t i = 0; i < projected_training_images.size(); i++) {
		distances.push_back(
				norm(projected_training_images[i], projected_test_image,
						CV_L2));
	}

	return distances;
}

//Distance de mahalanobis d'un vecteur vers un ensemble de vecteurs
vector<double> dist_vec_to_set_mahalanobis(
		vector<Mat> projected_training_images, Mat projected_test_image) {

	vector<double> distances;
	cout << "ca passe" << endl;

	for (size_t i = 0; i < projected_training_images.size(); i++) {
		vector<Mat> merged_mat;
		Mat covar;
		Mat icovar;
		Mat mean;

		merged_mat.push_back(projected_training_images[i]);
		merged_mat.push_back(projected_test_image);

		calcCovarMatrix(merged_mat, covar, mean, COVAR_NORMAL, CV_64F);
		//cout << "first mean :"<< mean<< endl;
		invert(covar, icovar, DECOMP_SVD);
		distances.push_back(
				Mahalanobis(projected_training_images[i], projected_test_image,
						icovar));
	}

	return distances;
}

//Prédiction de classe par l'algorithme du KNN

int kNN(vector<Mat> projected_training_images, Mat projected_test_image,
		vector<int> training_labels, int k) {
	//cout << "au moins je suis dedans"<<endl;
	//distance from a test vector to the trainig et of vector
	vector<double> distances_tab;
	distances_tab = dist_vec_to_set(projected_training_images,
			projected_test_image);

	// cout << "j ai avancé"<<endl;
	vector<double> sorted_distances;
	sorted_distances = distances_tab;
	//sorting of the distance array obtained
	std::sort(sorted_distances.begin(), sorted_distances.end());
//    for(size_t i =0; i< distances_tab.size(); i++){
//        	//cout << "on y est"<<endl;
//        	cout << "distances "<<i <<" : " <<sorted_distances[i]<< endl;
//        }

	if (sorted_distances[0] > 9000) {

		int classe = 8;
		return classe;
	} else {

		// cout << "pres du but"<<endl;

		//storage of k first results classes
		vector<int> knn;

		for (int i = 0; i < k; i++) {
			int pos = find(distances_tab.begin(), distances_tab.end(),
					sorted_distances[i]) - distances_tab.begin();
			knn.push_back(training_labels[pos]);
		}
		std::sort(knn.begin(), knn.end());

		//Determination of the number of classes
		int * compteur;
		compteur = new int[k];
		for (int i = 0; i < k; i++) {
			compteur[i] = 0;
		}

		for (int i = 0; i < k; i++) {

			compteur[i] = std::count(knn.begin(), knn.end(), knn[i]);
			i = i + compteur[i] - 1;
		}

		//Determination of the class with the biggest occurence
		int max_index = 0;
		for (int m = 1; m < k; m++) {
			if (compteur[max_index] < compteur[m]) {
				max_index = m;
			}
		}
		int classe = knn[max_index];

		return classe;
	}
}


// detection de visage pour la base d'apprentissage et de test
Mat detect(Mat frame) {

	Size eye_size;
	Size nose_size;
	double echelle;
	int nb_voisins;

	//redimensionnement des images
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows > 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows < 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows > 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows < 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	std::vector<Rect> faces;
	Mat frame_gray;

	//conversion en image en niveau de gris
	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

	//-- Detection des faces
	face_cascade.detectMultiScale(frame_gray, faces, echelle, nb_voisins, 0,
			Size(30, 30), Size(200, 200));

	vector<int> faces_index;

	//discrimination des faces
	for (size_t i = 0; i < faces.size(); i++) {

		vector<Rect> eyes;
		Mat face_region = frame_gray(faces[i]);

		// détection des yeux dans la face considérée
		eyes_cascade.detectMultiScale(face_region, eyes, 1.1, 3, 0, eye_size);


		vector<Rect> nose;

		// détection du nez dans la face considérée
		nose_cascade.detectMultiScale(face_region, nose, 1.1, 3, 0, nose_size);

		//critère d'acceptation
		if (eyes.size() + nose.size() >= 0) {
			faces_index.push_back(i);

			//a décommenter si vous voulez voir le tracé des yeux et du nez
//	 				Point pt1(faces[i].x, faces[i].y); // Display detected faces on main window - live stream from camera
//	 				Point pt2((faces[i].x + faces[i].height),
//	 						(faces[i].y + faces[i].width));
//	 				rectangle(frame, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);

			//			for (size_t j = 0; j < eyes.size(); j++) {
			//
			//				Point pt3(eyes[j].x + faces[i].x, eyes[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
			//				Point pt4((eyes[j].x + faces[i].x + eyes[j].height),
			//						(eyes[j].y + faces[i].y + eyes[j].width));
			//				rectangle(frame, pt3, pt4, Scalar(0, 0, 255), 2, 8, 0);
			//			}
			//
			//			for (size_t j = 0; j < nose.size(); j++) {
			//
			//				Point pt7(nose[j].x + faces[i].x, nose[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
			//				Point pt8((nose[j].x + faces[i].x + nose[j].height),
			//						(nose[j].y + faces[i].y + nose[j].width));
			//				rectangle(frame, pt7, pt8, Scalar(0, 255, 255), 2, 8, 0);
			//			}

		}
	}
	//Normalisation de l'image
	equalizeHist(frame_gray, frame_gray);
	Mat face_detected = frame_gray(faces[faces_index[0]]);
	//Redimensionnement pour l acp
	resize(face_detected, face_detected, Size(100, 100), 1.0, 1.0, INTER_CUBIC);
	return face_detected;
}

// normalisation de 0 à 225 d'une image avec des valeurs de pixels flottant
static Mat norm_0_255(InputArray _src) {
	Mat src = _src.getMat();
	// Create and return normalized image:
	Mat dst;
	switch (src.channels()) {
	case 1:
		cv::normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC1);
		break;
	case 3:
		cv::normalize(_src, dst, 0, 255, NORM_MINMAX, CV_8UC3);
		break;
	default:
		src.copyTo(dst);
		break;
	}
	return dst;
}

//Lecture des données
static void read_data(const string& filename, vector<Mat>& images,
		vector<int>& labels, char separator = ';') {
	std::ifstream file(filename.c_str(), ifstream::in);
	if (!file) {
		string error_message =
				"No valid input file was given, please check the given filename.";
		CV_Error(CV_StsBadArg, error_message);
	}
	string line, path, classlabel;
	while (getline(file, line)) {
		stringstream liness(line);
		getline(liness, path, separator);
		//cout << path << endl;
		getline(liness, classlabel);
		//cout << classlabel << endl;
		if (!path.empty() && !classlabel.empty()) {
			images.push_back(imread(path, 1));
			labels.push_back(atoi(classlabel.c_str()));
		}
	}
}

//Calcul du taux de précision
float bon_taux(int **conf_mat) {
	float taux = 0;
	float somme_diag = 0;
	float somme_tot = 0;

	//sum of diagonal elements is divided by sum of
	//all the matrix elements
	for (int i = 0; i < nb_classes; i++) {
		for (int j = 0; j < nb_classes; j++) {
			if (i == j) {
				somme_diag += conf_mat[i][j];
			}
			somme_tot += conf_mat[i][j];
		}
	}
	taux = somme_diag / somme_tot;
	return taux;

}

// detection de visage pour la base d'apprentissage
Mat detect_training(Mat frame) {

	Size eye_size;
	Size nose_size;
	double echelle;
	int nb_voisins;

	//redimensionnement des images
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows > 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows < 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	std::vector<Rect> faces;
	Mat frame_gray;

	//conversion en image en niveau de gris
	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

	//-- Detection des faces
	face_cascade.detectMultiScale(frame_gray, faces, echelle, nb_voisins, 0,
			Size(30, 30), Size(200, 200));

	vector<int> faces_index;

	//discrimination des faces
	for (size_t i = 0; i < faces.size(); i++) {

		vector<Rect> eyes;
		Mat face_region = frame_gray(faces[i]);

		// détection des yeux dans la face considérée
		eyes_cascade.detectMultiScale(face_region, eyes, 1.1, 3, 0, eye_size);

		vector<Rect> nose;

		// détection du nez dans la face considérée
		nose_cascade.detectMultiScale(face_region, nose, 1.1, 3, 0, nose_size);

		//critère d'acceptation
		if (eyes.size() + nose.size() >= 0) {
			faces_index.push_back(i);

			//a décommenter si vous voulez voir le tracé des yeux et du nez
 				Point pt1(faces[i].x, faces[i].y);
	 				Point pt2((faces[i].x + faces[i].height),
	 						(faces[i].y + faces[i].width));
	 				rectangle(frame, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);

						for (size_t j = 0; j < eyes.size(); j++) {

							Point pt3(eyes[j].x + faces[i].x, eyes[j].y + faces[i].y);
							Point pt4((eyes[j].x + faces[i].x + eyes[j].height),
									(eyes[j].y + faces[i].y + eyes[j].width));
							rectangle(frame, pt3, pt4, Scalar(0, 0, 255), 2, 8, 0);
						}

						for (size_t j = 0; j < nose.size(); j++) {

							Point pt7(nose[j].x + faces[i].x, nose[j].y + faces[i].y);
							Point pt8((nose[j].x + faces[i].x + nose[j].height),
									(nose[j].y + faces[i].y + nose[j].width));
							rectangle(frame, pt7, pt8, Scalar(0, 255, 255), 2, 8, 0);
						}

		}
	}

	//Normalisation de l'image
	equalizeHist(frame_gray, frame_gray);
	Mat face_detected = frame_gray(faces[faces_index[0]]);
	//Redimensionnement pour l acp
	resize(face_detected, face_detected, Size(100, 100), 1.0, 1.0, INTER_CUBIC);
	return face_detected;
}


// detection de visage pour l'image de test
vector<Rect> detect_test(Mat frame) {

	Size eye_size;
	Size nose_size;
	double echelle;
	int nb_voisins;

	//redimensionnement des images
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows > 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows < 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows > 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows < 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	std::vector<Rect> faces;
	Mat frame_gray;

	//conversion en image en niveau de gris
	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

	//-- Detection des faces
	face_cascade.detectMultiScale(frame_gray, faces, echelle, nb_voisins, 0,
			Size(30, 30), Size(200, 200));

	vector<int> faces_index;

	//discrimination des faces
	for (size_t i = 0; i < faces.size(); i++) {

		vector<Rect> eyes;
		Mat face_region = frame_gray(faces[i]);

		// détection des yeux dans la face considérée
		eyes_cascade.detectMultiScale(face_region, eyes, 1.1, 3, 0, eye_size);

		vector<Rect> nose;

		// détection du nez dans la face considérée
		nose_cascade.detectMultiScale(face_region, nose, 1.1, 3, 0, nose_size);

		//critère d'acceptation
		if (eyes.size() + nose.size() >= 1) {
			faces_index.push_back(i);
			Point pt1(faces[i].x, faces[i].y);
			Point pt2((faces[i].x + faces[i].height),
					(faces[i].y + faces[i].width));
			rectangle(frame, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);

						for (size_t j = 0; j < eyes.size(); j++) {

							Point pt3(eyes[j].x + faces[i].x, eyes[j].y + faces[i].y);
							Point pt4((eyes[j].x + faces[i].x + eyes[j].height),
									(eyes[j].y + faces[i].y + eyes[j].width));
							rectangle(frame, pt3, pt4, Scalar(0, 0, 255), 2, 8, 0);
						}

						for (size_t j = 0; j < nose.size(); j++) {

							Point pt7(nose[j].x + faces[i].x, nose[j].y + faces[i].y);
							Point pt8((nose[j].x + faces[i].x + nose[j].height),
									(nose[j].y + faces[i].y + nose[j].width));
							rectangle(frame, pt7, pt8, Scalar(0, 255, 255), 2, 8, 0);
						}

		}
	}

	//equalizeHist( frame_gray, frame_gray );
	vector<Rect> face_detected;
	for (size_t i = 0; i < faces_index.size(); i++) {

		face_detected.push_back(faces[faces_index[i]]);
		//resize(face_detected[i], face_detected[i], Size(100,100), 1.0, 1.0, INTER_CUBIC);
	}
	imshow("test", frame);
	//Enregistrement des images reconnues dans le dossier Resultat
	imwrite("resultat_rec_Multiple/Image_detectee.png",frame);

	return face_detected;
}


//Fonction principale
int main(int argc, const char *argv[]) {
    cout<<"*********MENU PRINCIPAL DU PROJET*********"<<endl;
    cout<<"1- Detection de visage"<<endl;
    cout<<"2- Reconnaissance de visage"<<endl;
    cout<<"Choix : $  ";
    int choixmenuprincipal;
    cin>>choixmenuprincipal;

    if (choixmenuprincipal==1){
       Mat frame;
    string nomimage="";
	cout<<"Entrer le nom de l'images se trouvant dans le repertoire :images "<<endl;
	cout<<"$ ";
	cin>>nomimage;
	string chemin_image ="images/"+nomimage;

	//Chargement des descripteurs
	if (!face_cascade.load(face_cascade_name)) {
		printf("--(!)Error loading face cascade\n");
		return -1;
	};
	if (!eyes_cascade.load(eyes_cascade_name)) {
		printf("--(!)Error loading eyes cascade\n");
		return -1;
	};
	if (!nose_cascade.load(nose_cascade_name)) {
		printf("--(!)Error loading eyes cascade\n");
		return -1;
	};

	//Lecture de l'image
	frame = imread(chemin_image, 1);
    cout<<"\n ***** Menu Detection ***** "<<endl;
    cout<<"1- Detection Simple"<<endl;
    cout<<"2- Detection avec discrimination"<<endl;
    cout<<"Choix :$ ";
    int choixmenudetection;
    cin>>choixmenudetection;
    if (choixmenudetection==1){
        //Détection des visages
	detectAndDisplaysimple(frame);
	imwrite("detection/Image_initiale_"+nomimage,frame);
    } else if (choixmenudetection==2){
    detectAndDisplaydiscrimination(frame);
    imwrite("detection/Image_initiale_"+nomimage,frame);
    }else cout<<"Veuillez faire un bon choix"<<endl;


	waitKey(0);

	return 0;
    }
    else if (choixmenuprincipal==2){

        cout<<"\n ******Menu reconnaissance de visage*******"<<endl;
        cout<<"1- Reconnaissance Simple"<<endl;
        cout<<"2- Reconnaissance Multiple"<<endl;
        cout<<"choix : $ ";
        int choixmenureconnaissancevisage;
        cin>>choixmenureconnaissancevisage;

        if (choixmenureconnaissancevisage==1){
            cout<<"\n ********Reconnaissance Simple*********"<<endl;
            cout<<"N.B. Le programme va dans ce cas verifier les deux fichiers suivants \n 1- apprentissage_rec_simple.txt \n 2- test_rec_simple.txt"<<endl;
            cout<<"En cas d'echec verifiez les fichier .txt, votre base d'apprentissage ainsi que votre base de test \n \n"<<endl;
//Chargement des descripteurs
	if (!face_cascade.load(face_cascade_name)) {
		printf("--(!)Error loading face cascade\n");
		return -1;
	};

	// lire les fichiers descriptifs de la base d'apprentissage et de test
	string training_file = "apprentissage_rec_simple.txt";
	string test_file = "test_rec_simple.txt";


	// vecteurs images apprentissage et test.
	vector<Mat> training_images;
	vector<Mat> test_images;
	vector<Mat> processed_images;

	// Nom des personnes
	vector<string> person_names;
	person_names.push_back("kolo");
	person_names.push_back("evina");
	person_names.push_back("olinga");
	person_names.push_back("fabien");
	person_names.push_back("jean");
	person_names.push_back("nobie");
	person_names.push_back("bien");
	person_names.push_back("tolo");

	// vecteurs labels d'images apprentissage et test.
	vector<int> training_labels;
	vector<int> test_labels;

	// Lecture des donnnees
	try {
		read_data(training_file, training_images, training_labels);
	} catch (cv::Exception& e) {
		cerr << "Error opening file \"" << training_file << "\". Reason: "
				<< e.msg << endl;
		// nothing more we can do
		exit(1);
	}

	try {
		read_data(test_file, test_images, test_labels);
	} catch (cv::Exception& e) {
		cerr << "Error opening file \"" << test_file << "\". Reason: " << e.msg
				<< endl;
		// nothing more we can do
		exit(1);
	}

	//Détection des images dans la base d'apprentissage
	for (size_t i = 0; i < training_images.size(); i++) {

		training_images.at(i) = detect(training_images[i]);

	}

	//Détection des images dans la base de test
	for (size_t i = 0; i < test_images.size(); i++) {

		processed_images.push_back(detect(test_images[i]));

	}

	//ACP
	Ptr<FaceRecognizer> model = createEigenFaceRecognizer();
	model->train(training_images, training_labels);

	// Récupération des valeurs propres
	Mat eigenvalues = model->getMat("eigenvalues");

	// Récupération des vecteurs propres
	Mat eigenvectors = model->getMat("eigenvectors");

	// Récupération de l'image moyenne
	Mat mean = model->getMat("mean");

	//projection des images de la base d'apprentissage
	vector<Mat> projected_training_images;

	projected_training_images = model->getMatVector("projections");

	//projection des images de la base de test
	vector<Mat> projected_test_images;
	//cout << "on est ici"<<endl;

	for (size_t i = 0; i < test_images.size(); i++) {
		//cout << "entre"<<endl;
		Mat projection = subspaceProject(eigenvectors, mean,
				processed_images[(int) i].reshape(1, 1));

		projected_test_images.push_back(projection);

		}

	//prédiction des labels
	vector<int> predicted_labels;
	for (size_t i = 0; i < test_labels.size(); i++) {
		predicted_labels.push_back(
				kNN(projected_training_images, projected_test_images[i],
						training_labels, 1));
		string identified_person = person_names[predicted_labels[i]];
		string result_message = format(
				" Classe prédite = %d / Classe réelle = %d.",
				predicted_labels[i], test_labels[i]);
		cout << "Image de " << person_names[test_labels[i]] << " : "
				<< result_message << endl;
		resize(test_images[i], test_images[i], Size(220, 250), 1.0, 1.0,
				INTER_CUBIC);
		putText(test_images[i], person_names[predicted_labels[i]],
				Point(test_images[i].cols / 110, 20), FONT_HERSHEY_PLAIN, 1.0,
				CV_RGB(0, 255, 0), 2.0);

		imshow(format("%d", i), test_images[i]);
		//Enregistrement des images reconnues dans le dossier Resultat
	    imwrite(format("%s/Test_%d.png", "Resultat_rec_simple", i), test_images[i]);

	}

	//déterminantion du nombre de classes
	sort(test_labels.begin(), test_labels.end());
	int compt = 0;
	std::vector<int> classes;

	for (size_t i = 0; i < test_labels.size(); i++) {

		compt = count(test_labels.begin(), test_labels.end(), test_labels[i]);
		classes.push_back(test_labels[i]);
		i = i + compt - 1;
		nb_classes++;
	}

	//creation de la matrice de cofusion
	int **confusion_matrix;
	confusion_matrix = new int*[nb_classes];

	for (int j = 0; j < nb_classes; j++) {
		confusion_matrix[j] = new int[nb_classes];
		for (int n = 0; n < nb_classes; n++) {
			confusion_matrix[j][n] = 0;
		}
	}

	//remplissage matrice de confusion
	for (size_t m = 0; m < test_images.size(); m++) {

		confusion_matrix[test_labels[m]][predicted_labels[m]]++;
	}

	//Affichage matrice de confusion
	cout << endl << "Matrice de confusion";
	for (int a = 0; a < nb_classes; a++) {
		for (int b = 0; b < nb_classes; b++) {

			cout << confusion_matrix[a][b] << " ";
		}
		cout << endl;

	}

	//affichage taux de précision
	cout << endl << "le taux de précision est :"
			<< bon_taux(confusion_matrix) * 100 << "%" << endl;

	// Affichage et enrégistrement de l'image moyenne

//        imshow("mean", norm_0_255(mean.reshape(1, training_images[0].rows)));
//
//        imwrite(format("%s/mean.png", result_folder.c_str()), norm_0_255(mean.reshape(1, training_images[0].rows)));
//
//    // Affichage et enrégistrement des vecteurs propres:
//    for (int i = 0; i <  eigenvectors.cols; i++) {
//        string msg = format("Eigenvalue #%d = %.5f", i, eigenvalues.at<double>(i));
//        cout << msg << endl;
//        // recupérer le vecteur propre i
//        Mat ev = eigenvectors.col(i).clone();
//
//        // redimensionner et mettre à l'echelle le vecteur propre i.
//        Mat grayscale = norm_0_255(ev.reshape(1, training_images[0].rows));
//
//
//        //Afichage et enrégistrement
//
//            imshow(format("eigenface_%d", i), grayscale);
//
//            imwrite(format("%s/eigenface_%d.png", result_folder.c_str(), i), grayscale);
//
//    }

	waitKey(0);

	return 0;

        } else if (choixmenureconnaissancevisage==2){
            cout<< "***************Reconnaissance Multiple***********"<<endl;
            //Chargement des descripteurs
	if (!face_cascade.load(face_cascade_name)) {
		printf("--(!)Error loading face cascade\n");
		return -1;
	};

	if (!eyes_cascade.load(eyes_cascade_name)) {
		printf("--(!)Error loading eyes cascade\n");
		return -1;
	};
	if (!nose_cascade.load(nose_cascade_name)) {
		printf("--(!)Error loading eyes cascade\n");
		return -1;
	};

	// lire les fichiers descriptifs de la base d'apprentissage
	string training_file = "apprentissage_rec_multiple.txt";

	//lire le nom du fichier test
	string test_file = "";
	cout<<"Veuillez entrer votre image de groupe, je t'en prie"<<endl;
	cout<<"$ ";
	cin>>test_file;

	// vecteurs images
	vector<Mat> training_images;
	Mat test_image;
	vector<Mat> processed_images;

	// Nom des personnes
	vector<string> person_names;
	person_names.push_back("Appedo");
	person_names.push_back("Nobby");
	person_names.push_back("Olivier");
	person_names.push_back("Paul");

	// vecteurs labels d'images apprentissage
	vector<int> training_labels;

	// Lecture des donnnees
	try {
		read_data(training_file, training_images, training_labels);
	} catch (cv::Exception& e) {
		cerr << "Error opening file \"" << training_file << "\". Reason: "
				<< e.msg << endl;
		// nothing more we can do
		exit(1);
	}
	test_image = imread(test_file, 1);

	//Détection des images dans la base d'apprentissage
	for (size_t i = 0; i < training_images.size(); i++) {

		training_images.at(i) = detect_training(training_images[i]);

	}

	//Détection des images dans la base de test
	vector<Rect> test_faces = detect_test(test_image);
	cout << "taille test_face :" << test_faces.size();
	resize(test_image, test_image, Size(1200, 1000), 1.0, 1.0, INTER_CUBIC);
	for (size_t i = 0; i < test_faces.size(); i++) {

		Mat face = test_image(test_faces[i]);

		processed_images.push_back(detect_training(face));
	}

	//ACP
	Ptr<FaceRecognizer> model = createEigenFaceRecognizer();
	model->train(training_images, training_labels);

	// Récupération des valeurs propres
	Mat eigenvalues = model->getMat("eigenvalues");

	// Récupération des vecteurs propres
	Mat eigenvectors = model->getMat("eigenvectors");

	// Récupération de l'image moyenne
	Mat mean = model->getMat("mean");

	//projection des images de la base d'apprentissage
	vector<Mat> projected_training_images;

	projected_training_images = model->getMatVector("projections");

	//projection des images de la base de test
	vector<Mat> projected_test_images;
	//cout << "on est ici"<<endl;

	for (size_t i = 0; i < processed_images.size(); i++) {
		//cout << "entre"<<endl;
		Mat projection = subspaceProject(eigenvectors, mean,
				processed_images[(int) i].reshape(1, 1));

		projected_test_images.push_back(projection);


	}

	//prédiction des labels
	vector<int> predicted_labels;
	for (size_t i = 0; i < processed_images.size(); i++) {
		predicted_labels.push_back(
				kNN(projected_training_images, projected_test_images[i],
						training_labels, 1));
		string identified_person = person_names[predicted_labels[i]];
		string result_message = format(" Classe prédite = %d ",
				predicted_labels[i]);
		cout << result_message << endl;
	}

	// affichage des nom des personnes reconnues dans l image de test
	for (size_t i = 0; i < test_faces.size(); i++) {

		Point pt1(test_faces[i].x, test_faces[i].y); // Display detected faces on main window - live stream from camera
		Point pt2((test_faces[i].x + test_faces[i].height),
				(test_faces[i].y + test_faces[i].width));
		rectangle(test_image, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);
		putText(test_image, person_names[predicted_labels[i]], pt1,
				FONT_HERSHEY_PLAIN, 1.0, CV_RGB(0, 255, 0), 2.0);

	}

	imshow(format("Resultat"), test_image);
    //Enregistrement de l'image avec des visages reconnus
	imwrite("resultat_rec_Multiple/Image_avec_visage_reconnu.png",test_image);

	waitKey(0);

	return 0;
        } else cout<<" Faites un bon choix !"<<endl;
    } else cout <<"Faites un bon choix !"<<endl;

}

// detection simple de visages dans l'image test
void detectAndDisplaysimple(Mat frame) {

	Size eye_size;
	Size nose_size;
	double echelle;
	int nb_voisins;

	//redimensionnement des images
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows > 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows < 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows > 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows < 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	std::vector<Rect> faces;
	Mat frame_gray;

	//conversion en image en niveau de gris
	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

	//Affichage de l'image originale
	imshow("image originale", frame);

	//-- Detection des faces
	face_cascade.detectMultiScale(frame_gray, faces, echelle, nb_voisins, 0,
			Size(30, 30), Size(200, 200));

	vector<int> faces_index;

            //discrimination des faces
	for (size_t i = 0; i < faces.size(); i++) {

		vector<Rect> eyes;
		Mat face_region = frame_gray(faces[i]);

		// détection des yeux dans la face considérée
		eyes_cascade.detectMultiScale(face_region, eyes, 1.1, 3, 0, eye_size);


		vector<Rect> nose;

		// détection du nez dans la face considérée
		nose_cascade.detectMultiScale(face_region, nose, 1.1, 3, 0, nose_size);

           //critère d'acceptation
		if (eyes.size() + nose.size() >= 1) {
			faces_index.push_back(i);
			Point pt1(faces[i].x, faces[i].y); // Display detected faces on main window - live stream from camera
			Point pt2((faces[i].x + faces[i].height),
					(faces[i].y + faces[i].width));
			rectangle(frame, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);

			/*for (size_t j = 0; j < eyes.size(); j++) {

				Point pt3(eyes[j].x + faces[i].x, eyes[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
				Point pt4((eyes[j].x + faces[i].x + eyes[j].height),
						(eyes[j].y + faces[i].y + eyes[j].width));
				rectangle(frame, pt3, pt4, Scalar(0, 0, 255), 2, 8, 0);
			}

			for (size_t j = 0; j < nose.size(); j++) {

				Point pt7(nose[j].x + faces[i].x, nose[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
				Point pt8((nose[j].x + faces[i].x + nose[j].height),
						(nose[j].y + faces[i].y + nose[j].width));
				rectangle(frame, pt7, pt8, Scalar(0, 255, 255), 2, 8, 0);
			}*/

		}


	}



	imshow(window_name, frame);
	imwrite("detection/Image_detectee_simple.png",frame);
}
// detection avec discrimination de visages dans l'image test
void detectAndDisplaydiscrimination(Mat frame) {

	Size eye_size;
	Size nose_size;
	double echelle;
	int nb_voisins;

	//redimensionnement des images
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows > 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols > frame.rows) && (frame.cols * frame.rows < 1200000)) {
		resize(frame, frame, Size(1200, 1000), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(5, 5);
		nose_size = Size(15, 15);
		echelle = 1.1;
		nb_voisins = 2;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows > 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_AREA);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	if ((frame.cols <= frame.rows) && (frame.cols * frame.rows < 55000)) {
		resize(frame, frame, Size(220, 250), 1.0, 1.0, CV_INTER_LINEAR);
		eye_size = Size(30, 30);
		nose_size = Size(50, 50);
		echelle = 1.01;
		nb_voisins = 1;
	}
	std::vector<Rect> faces;
	Mat frame_gray;

	//conversion en image en niveau de gris
	cvtColor(frame, frame_gray, COLOR_BGR2GRAY);

	//Affichage de l'image originale
	imshow("image originale", frame);

	//-- Detection des faces
	face_cascade.detectMultiScale(frame_gray, faces, echelle, nb_voisins, 0,
			Size(30, 30), Size(200, 200));

	vector<int> faces_index;

	//discrimination des faces
	for (size_t i = 0; i < faces.size(); i++) {

		vector<Rect> eyes;
		Mat face_region = frame_gray(faces[i]);

		// détection des yeux dans la face considérée
		eyes_cascade.detectMultiScale(face_region, eyes, 1.1, 3, 0, eye_size);


		vector<Rect> nose;

		// détection du nez dans la face considérée
		nose_cascade.detectMultiScale(face_region, nose, 1.1, 3, 0, nose_size);

		//critère d'acceptation
		if (eyes.size() + nose.size() >= 1) {
			faces_index.push_back(i);
			Point pt1(faces[i].x, faces[i].y); // Display detected faces on main window - live stream from camera
			Point pt2((faces[i].x + faces[i].height),
					(faces[i].y + faces[i].width));
			rectangle(frame, pt1, pt2, Scalar(255, 0, 255), 2, 8, 0);

			for (size_t j = 0; j < eyes.size(); j++) {

				Point pt3(eyes[j].x + faces[i].x, eyes[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
				Point pt4((eyes[j].x + faces[i].x + eyes[j].height),
						(eyes[j].y + faces[i].y + eyes[j].width));
				rectangle(frame, pt3, pt4, Scalar(0, 0, 255), 2, 8, 0);
			}

			for (size_t j = 0; j < nose.size(); j++) {

				Point pt7(nose[j].x + faces[i].x, nose[j].y + faces[i].y); // Display detected faces on main window - live stream from camera
				Point pt8((nose[j].x + faces[i].x + nose[j].height),
						(nose[j].y + faces[i].y + nose[j].width));
				rectangle(frame, pt7, pt8, Scalar(0, 255, 255), 2, 8, 0);
			}

		}
	}

	imshow(window_name, frame);
	imwrite("detection/Image_detectee_discrimination.png",frame);
}

